import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Customer Module Pages
import CustomerHome from "@/pages/customer/Home";
import CustomerProducts from "@/pages/customer/Products";
import CustomerCart from "@/pages/customer/Cart";
import CustomerCheckout from "@/pages/customer/Checkout";

// Admin Module Pages
import AdminDashboard from "@/pages/admin/Dashboard";
import AdminProducts from "@/pages/admin/Products";
import AdminOrders from "@/pages/admin/Orders";
import AdminReports from "@/pages/admin/Reports";

// Supplier Module Pages
import SupplierInventory from "@/pages/supplier/Inventory";
import SupplierOrders from "@/pages/supplier/Orders";
import SupplierProducts from "@/pages/supplier/Products";

function Router() {
  return (
    <Switch>
      {/* Customer Module Routes */}
      <Route path="/" component={CustomerHome} />
      <Route path="/products" component={CustomerProducts} />
      <Route path="/products/:category" component={CustomerProducts} />
      <Route path="/cart" component={CustomerCart} />
      <Route path="/checkout" component={CustomerCheckout} />
      
      {/* Admin Module Routes */}
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/products" component={AdminProducts} />
      <Route path="/admin/orders" component={AdminOrders} />
      <Route path="/admin/reports" component={AdminReports} />
      
      {/* Supplier Module Routes */}
      <Route path="/supplier" component={SupplierInventory} />
      <Route path="/supplier/inventory" component={SupplierInventory} />
      <Route path="/supplier/orders" component={SupplierOrders} />
      <Route path="/supplier/products" component={SupplierProducts} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
