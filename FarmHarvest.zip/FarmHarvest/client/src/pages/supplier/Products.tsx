import SupplierSidebar from "@/components/supplier/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Plus, Package, Sprout, Shield } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertProductSchema, type InsertProduct } from "@shared/schema";
import { useState } from "react";
import { z } from "zod";

// Mock supplier ID - in real app this would come from auth
const MOCK_SUPPLIER_ID = "supplier-1";

const productFormSchema = insertProductSchema.extend({
  price: z.string().min(1, "Price is required"),
  stock: z.string().min(1, "Stock is required"),
});

type ProductForm = z.infer<typeof productFormSchema>;

export default function SupplierProducts() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const form = useForm<ProductForm>({
    resolver: zodResolver(productFormSchema),
    defaultValues: {
      name: "",
      description: "",
      category: "seeds",
      price: "",
      stock: "",
      imageUrl: "",
      supplierId: MOCK_SUPPLIER_ID,
      isActive: true,
    },
  });

  const createProductMutation = useMutation({
    mutationFn: async (data: ProductForm) => {
      const productData: InsertProduct = {
        ...data,
        price: parseFloat(data.price).toString(),
        stock: parseInt(data.stock),
        supplierId: MOCK_SUPPLIER_ID,
      };
      const response = await apiRequest("POST", "/api/products", productData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Product added",
        description: "Your product has been added to the catalog successfully.",
      });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add product. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProductForm) => {
    createProductMutation.mutate(data);
  };

  const productCategories = [
    {
      id: "seeds",
      name: "Seeds",
      description: "Add agricultural seeds to your product catalog",
      icon: Sprout,
      color: "bg-farm-beige text-farm-green",
      iconColor: "text-farm-green",
    },
    {
      id: "pesticides",
      name: "Pesticides",
      description: "Add crop protection products to your catalog",
      icon: Shield,
      color: "bg-orange-50 text-farm-orange",
      iconColor: "text-farm-orange",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900">Add Products</h1>
              <p className="text-sm text-gray-600">Add new products to your supplier catalog</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-farm-green rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">S</span>
                </div>
                <span className="text-sm font-medium text-gray-700">Supplier Co.</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        <SupplierSidebar />

        <main className="flex-1 p-6">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 font-poppins">Add New Products</h2>
            <p className="text-gray-600">Expand your product catalog with new agricultural products</p>
          </div>

          {/* Quick Add Categories */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {productCategories.map((category) => (
              <Card key={category.id} className="hover:shadow-lg transition-shadow duration-200">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <category.icon className={`text-3xl mr-4 ${category.iconColor}`} />
                    <h4 className="text-2xl font-bold text-gray-900 font-poppins">{category.name}</h4>
                  </div>
                  <p className="text-gray-700 mb-6">
                    {category.description}
                  </p>
                  <Button 
                    onClick={() => {
                      form.setValue("category", category.id as "seeds" | "pesticides");
                      setIsDialogOpen(true);
                    }}
                    className="bg-farm-green text-white hover:bg-green-700 transition-colors duration-200 flex items-center gap-2"
                    data-testid={`button-add-${category.id}`}
                  >
                    <Plus className="h-4 w-4" />
                    Add {category.name}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Featured Benefits */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5 text-farm-green" />
                Why Add Products to FarmBasket?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-farm-beige rounded-lg flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">🌾</span>
                  </div>
                  <h5 className="font-semibold text-gray-900 mb-2">Reach More Farmers</h5>
                  <p className="text-sm text-gray-600">
                    Connect with thousands of farmers looking for quality agricultural products.
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-farm-beige rounded-lg flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">📈</span>
                  </div>
                  <h5 className="font-semibold text-gray-900 mb-2">Grow Your Business</h5>
                  <p className="text-sm text-gray-600">
                    Increase your sales with our easy-to-use platform and marketing tools.
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-farm-beige rounded-lg flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">🚚</span>
                  </div>
                  <h5 className="font-semibold text-gray-900 mb-2">Simple Management</h5>
                  <p className="text-sm text-gray-600">
                    Manage inventory, orders, and shipments all from one dashboard.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Getting Started Guide */}
          <Card>
            <CardHeader>
              <CardTitle>Getting Started</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-farm-green rounded-full flex items-center justify-center text-white text-sm font-semibold">
                    1
                  </div>
                  <div>
                    <h6 className="font-semibold text-gray-900">Choose Product Category</h6>
                    <p className="text-sm text-gray-600">
                      Select whether you're adding seeds or pesticides to your catalog.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-farm-green rounded-full flex items-center justify-center text-white text-sm font-semibold">
                    2
                  </div>
                  <div>
                    <h6 className="font-semibold text-gray-900">Fill Product Details</h6>
                    <p className="text-sm text-gray-600">
                      Provide comprehensive product information including name, description, and pricing.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-farm-green rounded-full flex items-center justify-center text-white text-sm font-semibold">
                    3
                  </div>
                  <div>
                    <h6 className="font-semibold text-gray-900">Set Stock Levels</h6>
                    <p className="text-sm text-gray-600">
                      Define your initial inventory levels and manage stock through the inventory dashboard.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-farm-green rounded-full flex items-center justify-center text-white text-sm font-semibold">
                    4
                  </div>
                  <div>
                    <h6 className="font-semibold text-gray-900">Go Live</h6>
                    <p className="text-sm text-gray-600">
                      Your products will be immediately available to customers on the platform.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Add Product Dialog */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Product</DialogTitle>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Name</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="e.g. Premium Tomato Seeds" data-testid="input-supplier-product-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-supplier-product-category">
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="seeds">Seeds</SelectItem>
                              <SelectItem value="pesticides">Pesticides</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            placeholder="Describe your product's features, benefits, and specifications..." 
                            data-testid="input-supplier-product-description"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price ($)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="0.01" 
                              {...field} 
                              placeholder="0.00" 
                              data-testid="input-supplier-product-price"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="stock"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Initial Stock Quantity</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              {...field} 
                              placeholder="100" 
                              data-testid="input-supplier-product-stock"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="imageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Image URL (Optional)</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="https://example.com/product-image.jpg" 
                            data-testid="input-supplier-product-image"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end space-x-2 pt-4">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsDialogOpen(false)}
                      data-testid="button-cancel-supplier-product"
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      className="bg-farm-green text-white hover:bg-green-700"
                      disabled={createProductMutation.isPending}
                      data-testid="button-save-supplier-product"
                    >
                      {createProductMutation.isPending ? "Adding Product..." : "Add Product"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  );
}
