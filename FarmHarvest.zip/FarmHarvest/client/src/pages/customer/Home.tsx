import Header from "@/components/customer/Header";
import ProductCard from "@/components/customer/ProductCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sprout, Shield, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product } from "@shared/schema";

export default function Home() {
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const featuredProducts = products.slice(0, 4);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-farm-green to-green-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold font-poppins mb-6">
                Growing Your Success, One Seed at a Time
              </h2>
              <p className="text-xl mb-8 text-green-100">
                Premium quality seeds and pesticides for farmers who demand the best results. 
                Trusted by thousands of agricultural professionals.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/products">
                  <Button 
                    className="bg-farm-orange text-white px-8 py-3 hover:bg-orange-600 transition-colors duration-200"
                    data-testid="button-shop-now"
                  >
                    Shop Now
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  className="border-2 border-white text-white px-8 py-3 hover:bg-white hover:text-farm-green transition-colors duration-200"
                  data-testid="button-learn-more"
                >
                  Learn More
                </Button>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                alt="Farmer holding soil with seedlings"
                className="rounded-xl shadow-2xl w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 font-poppins mb-4">Featured Products</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Discover our most popular and high-quality agricultural products trusted by farmers worldwide.
            </p>
          </div>
          
          {/* Product Categories */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            {/* Seeds Category */}
            <Card className="bg-farm-beige hover:shadow-lg transition-shadow duration-200">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <Sprout className="text-farm-green text-3xl mr-4" />
                  <h4 className="text-2xl font-bold text-gray-900 font-poppins">Premium Seeds</h4>
                </div>
                <p className="text-gray-700 mb-6">
                  High-quality, genetically superior seeds with excellent germination rates and disease resistance.
                </p>
                <Link href="/products/seeds">
                  <Button 
                    className="bg-farm-green text-white hover:bg-green-700 transition-colors duration-200 flex items-center gap-2"
                    data-testid="button-explore-seeds"
                  >
                    Explore Seeds
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
            
            {/* Pesticides Category */}
            <Card className="bg-green-50 hover:shadow-lg transition-shadow duration-200">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <Shield className="text-farm-orange text-3xl mr-4" />
                  <h4 className="text-2xl font-bold text-gray-900 font-poppins">Crop Protection</h4>
                </div>
                <p className="text-gray-700 mb-6">
                  Effective and environmentally responsible pesticides for healthy crop protection and maximum yield.
                </p>
                <Link href="/products/pesticides">
                  <Button 
                    className="bg-farm-orange text-white hover:bg-orange-600 transition-colors duration-200 flex items-center gap-2"
                    data-testid="button-shop-pesticides"
                  >
                    Shop Pesticides
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
          
          {/* Product Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {isLoading ? (
              // Loading skeletons
              [...Array(4)].map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <Skeleton className="h-48 w-full" />
                  <CardContent className="p-4">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-3" />
                    <div className="flex justify-between items-center">
                      <Skeleton className="h-6 w-16" />
                      <Skeleton className="h-10 w-24" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))
            )}
          </div>

          {/* View All Products */}
          <div className="text-center mt-12">
            <Link href="/products">
              <Button 
                variant="outline" 
                className="border-2 border-farm-green text-farm-green hover:bg-farm-green hover:text-white transition-colors duration-200 px-8 py-3"
                data-testid="button-view-all-products"
              >
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
