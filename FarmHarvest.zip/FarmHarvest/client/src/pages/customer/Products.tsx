import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/customer/Header";
import ProductCard from "@/components/customer/ProductCard";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Sprout, Shield, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import type { Product } from "@shared/schema";

export default function Products() {
  const { category } = useParams() as { category?: string };
  const [sortBy, setSortBy] = useState("name");

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: category ? ["/api/products/category", category] : ["/api/products"],
  });

  const getCategoryTitle = () => {
    if (category === "seeds") return "Seeds Collection";
    if (category === "pesticides") return "Pesticides & Crop Protection";
    return "All Products";
  };

  const getCategoryIcon = () => {
    if (category === "seeds") return <Sprout className="h-6 w-6 text-farm-green" />;
    if (category === "pesticides") return <Shield className="h-6 w-6 text-farm-orange" />;
    return null;
  };

  const getCategoryDescription = () => {
    if (category === "seeds") {
      return "High-quality seeds for optimal crop yield and growth. Choose from our premium selection of vegetable, grain, and specialty seeds.";
    }
    if (category === "pesticides") {
      return "Effective and safe crop protection solutions. Environmentally responsible pesticides for healthy farming practices.";
    }
    return "Browse our complete collection of agricultural products including seeds and pesticides for all your farming needs.";
  };

  const sortedProducts = [...products].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return parseFloat(a.price) - parseFloat(b.price);
      case "price-high":
        return parseFloat(b.price) - parseFloat(a.price);
      case "name":
      default:
        return a.name.localeCompare(b.name);
    }
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Page Header */}
      <section className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              {getCategoryIcon()}
              <h1 className="text-3xl font-bold text-gray-900 font-poppins ml-3">
                {getCategoryTitle()}
              </h1>
            </div>
            <p className="text-gray-600 max-w-2xl mx-auto">
              {getCategoryDescription()}
            </p>
            
            {category && (
              <div className="mt-6">
                <Badge className="text-sm px-4 py-2">
                  {products.length} {products.length === 1 ? "product" : "products"} found
                </Badge>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Filters and Sort */}
      <section className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-5 w-5 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Filters & Sort</span>
            </div>
            
            <div className="flex gap-4">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48" data-testid="select-sort">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name (A-Z)</SelectItem>
                  <SelectItem value="price-low">Price (Low to High)</SelectItem>
                  <SelectItem value="price-high">Price (High to Low)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <Skeleton className="h-48 w-full" />
                  <CardContent className="p-4">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-3" />
                    <div className="flex justify-between items-center">
                      <Skeleton className="h-6 w-16" />
                      <Skeleton className="h-10 w-24" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-12">
              <div className="mb-4">
                {category === "seeds" ? (
                  <Sprout className="h-16 w-16 text-gray-400 mx-auto" />
                ) : category === "pesticides" ? (
                  <Shield className="h-16 w-16 text-gray-400 mx-auto" />
                ) : (
                  <div className="h-16 w-16 bg-gray-200 rounded-full mx-auto" />
                )}
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No products found</h3>
              <p className="text-gray-500 mb-6">
                We couldn't find any products in this category. Check back later for new arrivals.
              </p>
              <Button variant="outline" data-testid="button-browse-all">
                Browse All Products
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {sortedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
