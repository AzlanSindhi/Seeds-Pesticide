import AdminSidebar from "@/components/admin/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, TrendingDown, DollarSign, ShoppingCart, Users, Package, Calendar, Download } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import type { DashboardStats } from "@/lib/types";

export default function AdminReports() {
  const [dateRange, setDateRange] = useState("30");

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/analytics/dashboard"],
  });

  const { data: orders = [], isLoading: ordersLoading } = useQuery({
    queryKey: ["/api/orders"],
  });

  const { data: products = [], isLoading: productsLoading } = useQuery({
    queryKey: ["/api/products"],
  });

  // Calculate metrics
  const totalRevenue = stats?.totalRevenue || 0;
  const totalOrders = stats?.totalOrders || 0;
  const totalCustomers = stats?.totalCustomers || 0;
  const totalProducts = stats?.totalProducts || 0;

  // Calculate order trends (mock data for percentage changes)
  const revenueChange = 12.5;
  const orderChange = 8.3;
  const customerChange = -2.1;
  const productChange = 15.7;

  // Get order status distribution
  const ordersByStatus = orders.reduce((acc: any, order: any) => {
    acc[order.status] = (acc[order.status] || 0) + 1;
    return acc;
  }, {});

  // Get category distribution
  const productsByCategory = products.reduce((acc: any, product: any) => {
    acc[product.category] = (acc[product.category] || 0) + 1;
    return acc;
  }, {});

  // Low stock products
  const lowStockProducts = products.filter((product: any) => product.stock < 10);

  const StatCard = ({ 
    title, 
    value, 
    change, 
    icon: Icon, 
    color,
    testId 
  }: { 
    title: string; 
    value: string | number; 
    change: number; 
    icon: any; 
    color: string;
    testId: string;
  }) => (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-600 text-sm">{title}</p>
            <p className="text-2xl font-bold text-gray-900" data-testid={testId}>
              {value}
            </p>
            <div className="flex items-center mt-2">
              {change >= 0 ? (
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
              )}
              <span className={`text-sm ${change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {change >= 0 ? '+' : ''}{change}%
              </span>
            </div>
          </div>
          <div className={`p-3 rounded-lg ${color}`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900">Reports & Analytics</h1>
              <p className="text-sm text-gray-600">Comprehensive business insights and metrics</p>
            </div>
            <div className="flex items-center space-x-4">
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-40" data-testid="select-date-range">
                  <Calendar className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">Last 7 days</SelectItem>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 90 days</SelectItem>
                  <SelectItem value="365">Last year</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" className="flex items-center gap-2" data-testid="button-export-report">
                <Download className="h-4 w-4" />
                Export
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-farm-green rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">A</span>
                </div>
                <span className="text-sm font-medium text-gray-700">Admin User</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 font-poppins">Business Analytics</h2>
            <p className="text-gray-600">Track your store's performance and growth metrics</p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {statsLoading ? (
              [...Array(4)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <Skeleton className="h-4 w-20 mb-2" />
                        <Skeleton className="h-8 w-16 mb-2" />
                        <Skeleton className="h-4 w-12" />
                      </div>
                      <Skeleton className="h-12 w-12 rounded-lg" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <>
                <StatCard
                  title="Total Revenue"
                  value={`$${totalRevenue.toFixed(2)}`}
                  change={revenueChange}
                  icon={DollarSign}
                  color="bg-farm-green"
                  testId="text-reports-revenue"
                />
                <StatCard
                  title="Total Orders"
                  value={totalOrders}
                  change={orderChange}
                  icon={ShoppingCart}
                  color="bg-farm-orange"
                  testId="text-reports-orders"
                />
                <StatCard
                  title="Customers"
                  value={totalCustomers}
                  change={customerChange}
                  icon={Users}
                  color="bg-blue-500"
                  testId="text-reports-customers"
                />
                <StatCard
                  title="Products"
                  value={totalProducts}
                  change={productChange}
                  icon={Package}
                  color="bg-purple-500"
                  testId="text-reports-products"
                />
              </>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Revenue Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Revenue Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-gray-50 rounded flex items-center justify-center">
                  <div className="text-center">
                    <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">Revenue Chart</p>
                    <p className="text-sm text-gray-400">Chart implementation needed</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Order Status Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Order Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="space-y-3">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <Skeleton className="h-4 w-20" />
                        <Skeleton className="h-4 w-8" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {Object.entries(ordersByStatus).map(([status, count]) => (
                      <div key={status} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge className={`capitalize ${
                            status === 'delivered' ? 'bg-green-100 text-green-800' :
                            status === 'shipped' ? 'bg-blue-100 text-blue-800' :
                            status === 'processing' ? 'bg-yellow-100 text-yellow-800' :
                            status === 'pending' ? 'bg-orange-100 text-orange-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {status}
                          </Badge>
                        </div>
                        <span className="font-semibold" data-testid={`text-status-count-${status}`}>
                          {count as number}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Product Categories */}
            <Card>
              <CardHeader>
                <CardTitle>Product Categories</CardTitle>
              </CardHeader>
              <CardContent>
                {productsLoading ? (
                  <div className="space-y-3">
                    {[...Array(2)].map((_, i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <Skeleton className="h-4 w-16" />
                        <Skeleton className="h-4 w-8" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {Object.entries(productsByCategory).map(([category, count]) => (
                      <div key={category} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <div className="flex items-center gap-2">
                          <Badge className={`${
                            category === 'seeds' ? 'bg-farm-beige text-farm-green' : 'bg-orange-50 text-farm-orange'
                          }`}>
                            {category}
                          </Badge>
                        </div>
                        <span className="font-semibold" data-testid={`text-category-count-${category}`}>
                          {count as number} products
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Low Stock Alert */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-yellow-600" />
                  Low Stock Alert
                </CardTitle>
              </CardHeader>
              <CardContent>
                {productsLoading ? (
                  <div className="space-y-3">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="flex items-center justify-between p-3 border rounded">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-4 w-8" />
                      </div>
                    ))}
                  </div>
                ) : lowStockProducts.length === 0 ? (
                  <div className="text-center py-8">
                    <Package className="h-12 w-12 text-green-500 mx-auto mb-4" />
                    <p className="text-green-600 font-medium">All products are well stocked!</p>
                    <p className="text-sm text-gray-500">No items are running low on inventory.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {lowStockProducts.slice(0, 5).map((product: any) => (
                      <div key={product.id} className="flex items-center justify-between p-3 border border-yellow-200 bg-yellow-50 rounded">
                        <div>
                          <p className="font-medium text-gray-900" data-testid={`text-low-stock-name-${product.id}`}>
                            {product.name}
                          </p>
                          <Badge className={product.category === 'seeds' ? 'bg-farm-beige text-farm-green' : 'bg-orange-50 text-farm-orange'}>
                            {product.category}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <span className="text-sm font-semibold text-red-600" data-testid={`text-low-stock-quantity-${product.id}`}>
                            {product.stock} left
                          </span>
                        </div>
                      </div>
                    ))}
                    {lowStockProducts.length > 5 && (
                      <p className="text-sm text-gray-500 text-center">
                        +{lowStockProducts.length - 5} more items with low stock
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
