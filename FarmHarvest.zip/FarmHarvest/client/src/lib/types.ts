export interface CartItemWithProduct {
  id: string;
  customerId: string;
  productId: string;
  quantity: number;
  createdAt: Date | null;
  product: {
    id: string;
    name: string;
    price: string;
    imageUrl: string | null;
    category: "seeds" | "pesticides";
    stock: number;
  };
}

export interface OrderWithItems {
  id: string;
  customerId: string;
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled";
  totalAmount: string;
  shippingAddress: string;
  createdAt: Date | null;
  items: Array<{
    id: string;
    productId: string;
    quantity: number;
    priceAtTime: string;
    product: {
      name: string;
      imageUrl: string | null;
    };
  }>;
}

export interface DashboardStats {
  totalRevenue: number;
  totalOrders: number;
  totalCustomers: number;
  totalProducts: number;
}
