import { Link, useLocation } from "wouter";
import { ShoppingCart, Search, Sprout, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useCart } from "@/hooks/useCart";
import { useState } from "react";

export default function Header() {
  const [location] = useLocation();
  const { cartCount } = useCart();
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const navigation = [
    { name: "Home", href: "/" },
    { name: "Seeds", href: "/products/seeds" },
    { name: "Pesticides", href: "/products/pesticides" },
    { name: "All Products", href: "/products" },
  ];

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center" data-testid="link-home">
            <Sprout className="text-farm-green text-2xl mr-2" />
            <h1 className="text-2xl font-bold text-farm-green font-poppins">FarmBasket</h1>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`text-gray-700 hover:text-farm-green transition-colors duration-200 font-medium ${
                  location === item.href ? "text-farm-green" : ""
                }`}
                data-testid={`link-${item.name.toLowerCase().replace(" ", "-")}`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Search & Actions */}
          <div className="flex items-center space-x-4">
            {/* Search */}
            <div className="relative hidden sm:block">
              <Input
                type="text"
                placeholder="Search products..."
                className="w-64 pl-10 pr-4 py-2 focus:ring-2 focus:ring-farm-green focus:border-transparent"
                data-testid="input-search"
              />
              <Search className="absolute left-3 top-3 text-gray-400 h-4 w-4" />
            </div>

            {/* Mobile Search Toggle */}
            <Button
              variant="ghost"
              size="sm"
              className="sm:hidden"
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              data-testid="button-search-toggle"
            >
              <Search className="h-5 w-5" />
            </Button>

            {/* Cart */}
            <Link href="/cart" data-testid="link-cart">
              <Button
                variant="ghost"
                size="sm"
                className="relative p-2 text-gray-700 hover:text-farm-green transition-colors duration-200"
              >
                <ShoppingCart className="h-5 w-5" />
                {cartCount > 0 && (
                  <span
                    className="absolute -top-1 -right-1 bg-farm-orange text-white text-xs rounded-full h-5 w-5 flex items-center justify-center"
                    data-testid="text-cart-count"
                  >
                    {cartCount}
                  </span>
                )}
              </Button>
            </Link>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden" data-testid="button-mobile-menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <div className="flex flex-col space-y-4 mt-8">
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className="text-lg font-medium text-gray-700 hover:text-farm-green transition-colors"
                      data-testid={`mobile-link-${item.name.toLowerCase().replace(" ", "-")}`}
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              </SheetContent>
            </Sheet>

            {/* Module Switcher for Demo */}
            <div className="hidden lg:flex space-x-2">
              <Link href="/admin" data-testid="link-admin">
                <Button variant="outline" size="sm">
                  Admin
                </Button>
              </Link>
              <Link href="/supplier" data-testid="link-supplier">
                <Button variant="outline" size="sm">
                  Supplier
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Mobile Search */}
        {isSearchOpen && (
          <div className="sm:hidden pb-4">
            <Input
              type="text"
              placeholder="Search products..."
              className="w-full"
              data-testid="input-mobile-search"
            />
          </div>
        )}
      </div>
    </header>
  );
}
