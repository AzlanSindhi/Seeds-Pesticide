import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Sprout, Shield } from "lucide-react";
import { useCart } from "@/hooks/useCart";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart, isAddingToCart } = useCart();

  const handleAddToCart = () => {
    addToCart({ productId: product.id });
  };

  const getCategoryIcon = (category: string) => {
    return category === "seeds" ? (
      <Sprout className="h-4 w-4 text-farm-green" />
    ) : (
      <Shield className="h-4 w-4 text-farm-orange" />
    );
  };

  const getCategoryColor = (category: string) => {
    return category === "seeds" ? "bg-farm-beige text-farm-green" : "bg-orange-50 text-farm-orange";
  };

  return (
    <Card className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200 overflow-hidden">
      <div className="aspect-square overflow-hidden">
        <img
          src={product.imageUrl || "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"}
          alt={product.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-200"
        />
      </div>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h5 className="font-semibold text-gray-900 mb-1" data-testid={`text-product-name-${product.id}`}>
            {product.name}
          </h5>
          <Badge className={`${getCategoryColor(product.category)} flex items-center gap-1`}>
            {getCategoryIcon(product.category)}
            {product.category}
          </Badge>
        </div>
        
        {product.description && (
          <p className="text-gray-600 text-sm mb-3 line-clamp-2" data-testid={`text-product-description-${product.id}`}>
            {product.description}
          </p>
        )}
        
        <div className="flex items-center justify-between mb-3">
          <span className="text-xl font-bold text-farm-green" data-testid={`text-product-price-${product.id}`}>
            ${parseFloat(product.price).toFixed(2)}
          </span>
          <div className="text-sm text-gray-500">
            <span data-testid={`text-product-stock-${product.id}`}>
              {product.stock > 0 ? `${product.stock} in stock` : "Out of stock"}
            </span>
          </div>
        </div>
        
        <Button
          onClick={handleAddToCart}
          disabled={product.stock === 0 || isAddingToCart}
          className="w-full bg-farm-orange text-white hover:bg-orange-600 transition-colors duration-200 flex items-center justify-center gap-2"
          data-testid={`button-add-to-cart-${product.id}`}
        >
          <ShoppingCart className="h-4 w-4" />
          {product.stock === 0 ? "Out of Stock" : isAddingToCart ? "Adding..." : "Add to Cart"}
        </Button>
      </CardContent>
    </Card>
  );
}
