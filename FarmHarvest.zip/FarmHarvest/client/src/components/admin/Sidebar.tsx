import { Link, useLocation } from "wouter";
import { 
  BarChart3, 
  Box, 
  ShoppingCart, 
  Users, 
  Truck, 
  TrendingUp, 
  Settings,
  Sprout,
  Home
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  {
    name: "Dashboard",
    href: "/admin/dashboard",
    icon: BarChart3,
    section: "Main"
  },
  {
    name: "Products", 
    href: "/admin/products",
    icon: Box,
    section: "Main"
  },
  {
    name: "Orders",
    href: "/admin/orders", 
    icon: ShoppingCart,
    section: "Main"
  },
  {
    name: "Customers",
    href: "/admin/customers",
    icon: Users,
    section: "Main"
  },
  {
    name: "Suppliers",
    href: "/admin/suppliers",
    icon: Truck,
    section: "Main"
  },
  {
    name: "Reports",
    href: "/admin/reports",
    icon: TrendingUp,
    section: "Analytics"
  },
  {
    name: "Settings",
    href: "/admin/settings",
    icon: Settings,
    section: "Analytics"
  }
];

export default function AdminSidebar() {
  const [location] = useLocation();

  const sections = [...new Set(navigation.map(item => item.section))];

  return (
    <aside className="w-64 bg-white shadow-sm h-screen">
      <div className="p-6">
        <Link href="/" className="flex items-center" data-testid="link-home">
          <Sprout className="text-farm-green text-2xl mr-3" />
          <span className="text-xl font-bold text-gray-900">FarmBasket</span>
        </Link>
        <p className="text-sm text-gray-600 mt-1">Admin Panel</p>
      </div>

      <nav className="mt-6">
        {sections.map((section) => (
          <div key={section}>
            <div className="px-6 py-3">
              <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">
                {section}
              </p>
            </div>
            {navigation
              .filter(item => item.section === section)
              .map((item) => {
                const isActive = location === item.href || (item.href === "/admin/dashboard" && location === "/admin");
                return (
                  <Link key={item.name} href={item.href} data-testid={`link-${item.name.toLowerCase()}`}>
                    <div
                      className={cn(
                        "flex items-center px-6 py-3 text-gray-700 hover:bg-gray-50 transition-colors",
                        isActive && "bg-farm-beige border-r-3 border-farm-green text-farm-green"
                      )}
                    >
                      <item.icon className={cn("mr-3 h-5 w-5", isActive && "text-farm-green")} />
                      {item.name}
                    </div>
                  </Link>
                );
              })}
          </div>
        ))}
      </nav>

      <div className="absolute bottom-4 left-4">
        <Link href="/" data-testid="link-back-to-store">
          <div className="flex items-center text-sm text-gray-600 hover:text-farm-green transition-colors">
            <Home className="h-4 w-4 mr-2" />
            Back to Store
          </div>
        </Link>
      </div>
    </aside>
  );
}
